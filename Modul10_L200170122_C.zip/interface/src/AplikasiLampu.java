
import java.util.Scanner;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author LAB-RPL
 */
public class AplikasiLampu {
    public static void main(String[] args) {
        Lampu lamp = new Lampu();
        Scanner sc = new Scanner(System.in);
        lamp.statusLampu = lamp.setSaklar(0);
        
        while(true){
                 
        System.out.println("Status Lampu = "+lamp.statusLampu+"\nKetikan");
        System.out.println("1 untuk Menyalakan lampu \n0 untuk mematikan lampu \n2 untuk meredupkan Lampu \n");
       
        
        switch (sc.nextInt()){
            case 0:
                lamp.matikanLampu();
                break;
            case 1:
                lamp.hidupkanLampu();
                break;
            case 2:
                lamp.redupkanLampu();
                break;
            default:
                break;
        }
        }

                
                
    }
    
    
}
