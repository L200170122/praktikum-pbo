/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author LAB-RPL
 */
public class Lampu implements Intlampu{
    public int statusLampu;
   
    @Override
    public void matikanLampu() {
       switch (statusLampu){
           case 0:
               System.out.println("Lampu Dalam Keadaan Mati");
               break;
           case 1:
               statusLampu=0;
               System.out.println("Lampu dimatikan");
               break;
           case 2:
               statusLampu=0;
               System.out.println("Lampu yang redup sudah dimatikan");
               break;
           default:
               break;
       } 
       
        
        
    }

    @Override
    public void hidupkanLampu() {
      switch (statusLampu){
           case 0:
               statusLampu=1;
               System.out.println("Lampu mati sudah Hidup \n***");
               break;
           case 1:
               statusLampu=1;
               System.out.println("Lampu dihidupkan \n***");
               break;
           case 2:
               statusLampu=1;
               System.out.println("Lampu sudah nyala\n***");
               break;
           default:
               break;
       } 
        
        
    }

    @Override
    public void redupkanLampu() {
       switch (statusLampu){
           case 0:
               statusLampu=2;
               System.out.println("Lampu Dalam Keadaan redup \n**");
               break;
           case 1:
               statusLampu=2;
               System.out.println("Lampu diredupkan \n**");
               break;
           case 2:
               statusLampu=2;
               System.out.println("Lampu sudah redup \n**");
               break;
           default:
               break;
       } 
          
    }
    
   
    public int setSaklar(int saklar){
        return statusLampu=saklar;
    }
    

   
    
}
